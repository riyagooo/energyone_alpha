# CHANGELOG.md

## [1.0.4] - 2023-10-04

- Update dependencies

## [1.0.3] - 2023-05-06

- Dependencies update

## [1.0.2] - 2023-04-11

- Dependency updates

## [1.0.1] - 2023-02-13

- Minor changes
- Dependency updates

## [1.0.0] - 2022-07-28

First release