<template>
  <div class="flex flex-col min-h-screen overflow-hidden">

    <!-- Site header -->
    <header class="absolute w-full z-30">
      <div class="max-w-6xl mx-auto px-4 sm:px-6">
        <div class="flex items-center justify-between h-16 md:h-20">

          <!-- Site branding -->
          <div class="shrink-0 mr-4">
            <!-- Logo -->
            <router-link class="block" to="/" aria-label="Cruip">
              <svg class="w-8 h-8" viewBox="0 0 32 32" xmlns:xlink="http://www.w3.org/1999/xlink">
                <defs>
                  <radialGradient cx="50%" cy="89.845%" fx="50%" fy="89.845%" r="108.567%" gradientTransform="matrix(-.00915 -.82755 .99996 -.00757 -.394 1.319)" id="logo1-b">
                    <stop stop-color="#3B82F6" stop-opacity=".64" offset="0%" />
                    <stop stop-color="#F472B6" stop-opacity=".876" offset="100%" />
                  </radialGradient>
                  <radialGradient cx="50%" cy="89.845%" fx="50%" fy="89.845%" r="108.567%" gradientTransform="matrix(-.00915 -.82755 .99996 -.00757 -.394 1.319)" id="logo1-d">
                    <stop stop-color="#3B82F6" stop-opacity=".64" offset="0%" />
                    <stop stop-color="#D375C2" stop-opacity=".833" offset="50.358%" />
                    <stop stop-color="#FBCFE8" stop-opacity=".876" offset="100%" />
                  </radialGradient>
                  <path d="M12 32c8-6.915 12-12.582 12-17 0-6.627-5.373-12-12-12S0 8.373 0 15c0 4.418 4 10.085 12 17Z" id="logo1-a" />
                  <path d="M20 29c8-6.915 12-12.582 12-17 0-6.627-5.373-12-12-12S8 5.373 8 12c0 4.418 4 10.085 12 17Z" id="logo1-c" />
                </defs>
                <g fill="none" fill-rule="evenodd">
                  <use fill="url(#logo1-b)" opacity=".64" transform="matrix(1 0 0 -1 0 35)" xlink:href="#logo1-a" />
                  <use fill="url(#logo1-d)" opacity=".961" xlink:href="#logo1-c" />
                </g>
              </svg>
            </router-link>
          </div>

        </div>
      </div>
    </header>

    <main class="relative grow flex">

      <!-- Content -->
      <div class="w-full bg-gray-900">

        <div class="h-full flex flex-col justify-center before:min-h-[4rem] md:before:min-h-[5rem] before:flex-1 after:flex-1">

          <div class="px-4 sm:px-6">
            <div class="w-full max-w-sm mx-auto">
              <div class="py-16 md:py-20">

                <div class="mb-8">
                  <h1 class="h2 font-uncut-sans mb-4">Reset password</h1>
                  <p class="text-gray-400">Enter your email address. If an account exists, you’ll receive an email with a password reset link soon.</p>
                </div>

                <!-- Form -->
                <form>
                  <div class="space-y-4">
                    <div>
                      <label class="block text-sm text-gray-400 font-medium mb-1" for="email">Email</label>
                      <input id="email" class="form-input py-2 w-full" type="email" required />
                    </div>
                  </div>
                  <div class="mt-6">
                    <button class="btn-sm text-white bg-gradient-to-t from-blue-600 to-blue-400 hover:to-blue-500 w-full shadow-lg group">
                      Reset Password <span class="tracking-normal text-blue-200 group-hover:translate-x-0.5 transition-transform duration-150 ease-in-out ml-1">-&gt;</span>
                    </button>
                  </div>
                </form>

              </div>
            </div>
          </div>

        </div>

      </div>

      <!-- Right side -->
      <div class="hidden lg:block shrink-0 w-1/3 overflow-hidden before:bg-gray-800 before:absolute before:inset-0 before:-z-10">
        <div class="absolute left-1/2 -translate-x-1/2 pointer-events-none -z-10" aria-hidden="true">
          <img src="../images/hero-illustration.svg" class="max-w-none" width="2143" height="737" alt="Hero Illustration">
        </div>
        <div class="absolute left-1/2 -translate-x-1/2 pointer-events-none -z-10" aria-hidden="true">
          <img src="../images/auth-illustration.svg" class="max-w-none" width="1440" height="880" alt="Auth Illustration">
        </div>
      </div>

    </main>

  </div>
</template>

<script>
export default {
  name: 'ResetPassword',
}
</script>